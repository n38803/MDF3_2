Shaun Thompson
MDF3 1503


Github: https://github.com/n38803/MDF3_2


My wife and I had to rush my 13month old daughter to the emergency room on Wednesday as we found out that she has a severe reaction to peanut butter.  I thought I could still make everything in on time by Thursday night, hence the lack of an email, but my wife got called into work on Thursday so I was stuck watching our 14