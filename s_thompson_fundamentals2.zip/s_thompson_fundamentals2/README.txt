Shaun Thompson
MDF3 1502
Week 2 Application: Fundamentals

GitHub: https://github.com/n38803/MDF3_2

Special Instructions:

1. Fixed issue with PendingIntent forcing pause in application.
2. Application has 2 distinctly different UIs when in portrait vs landscape orientation.  Persisting service leak force closes the application. My video shows both orientations working, just can’t seem to figure out how to safely unbind and save instance of the activity.


Image Credit:
http://www.fullsail.edu/
http://www.imgarcade.com/

Song Credit:
All songs written, recorded, & performed by Shaun Thompson
[www.soundcloud.com/vocalrevolver]