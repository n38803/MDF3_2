Shaun Thompson
MDF3 1402
Week 1 Application: Fundamentals

GitHub: https://github.com/n38803/MDF3_2

Special Instructions:

1. Play button functions as play & pause
2. When returning from pending intent the song pauses.  This is due to a conditional in my onPlay() method.  The criteria is met to return back to the application, it simply requires that you hit “Play” again to continue where the song left off.  I am trying to figure out how to correct the conditional logic to resolve.


Image Credit:
http://www.fullsail.edu/
http://www.imgarcade.com/

Song Credit:
All songs written, recorded, & performed by Shaun Thompson
[www.soundcloud.com/vocalrevolver]